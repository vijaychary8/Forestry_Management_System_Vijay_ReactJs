import React, { Component } from 'react'
import User from "./user";
import Admin from './admin';
import "./login.css";


export default class Login extends Component {

    constructor(props) {
        super(props);
        this.state = {isRegisterOpen: true, isLoginOpen: false};
      }
    

    showLoginBox() {
        this.setState({isLoginOpen: true, isRegisterOpen: false});
      }
    
      showRegisterBox() {
        this.setState({isRegisterOpen: true, isLoginOpen: false});
      }
    
    render() {

        return (
            <div className="root-container ">

                     <div className="box-controller">
       <div
         className={"controller " + (this.state.isLoginOpen
         ? "selected-controller"
         : "")}
         onClick={this
         .showLoginBox
         .bind(this)}>
         User
       </div>
       <div
         className={"controller " + (this.state.isRegisterOpen
         ? "selected-controller"
         : "")}
         onClick={this
         .showRegisterBox
         .bind(this)}>
         Admin
       </div>

       </div>
       <div className="box-container">
      {this.state.isLoginOpen && <User/>}
      {this.state.isRegisterOpen && <Admin/>}
     </div>

                
            </div>
        )
    }
}

